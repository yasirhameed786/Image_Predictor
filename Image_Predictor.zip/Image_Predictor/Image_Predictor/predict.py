import cv2
import numpy as np
import tensorflow as tf

model = tf.keras.models.load_model('final_model.keras')

cap = cv2.VideoCapture(0) 

while True:
    ret, frame = cap.read()
    if not ret:
        break

    img = cv2.resize(frame, (150, 150))
    img = np.expand_dims(img, axis=0)  
    img = img / 255.0  

    prediction = model.predict(img)

    print("Prediction Value (0 to 1):", prediction)

    label = 'class_1' if prediction < 0.5 else 'class_2'

    print("Predicted Label:", label)

    cv2.putText(frame, f'Prediction: {label}', (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

    cv2.imshow('Webcam Prediction', frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
